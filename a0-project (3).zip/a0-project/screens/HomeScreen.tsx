import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  ActivityIndicator,
  ScrollView,
  Dimensions,
  Animated,
  FlatList,
  Platform,
  TextInput,
  KeyboardAvoidingView,
  TouchableWithoutFeedback,
  Keyboard,
  Image,
} from 'react-native';
import Svg, { Circle, Path, G } from 'react-native-svg';
import { BarCodeScanner } from 'expo-barcode-scanner';
import { MaterialIcons, FontAwesome5, Ionicons, MaterialCommunityIcons, AntDesign } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

// Google Sheets integration
const SHEET_ID = '1sixnvtgob-oey6RUcKD01uCroMmY10IGKsz9TUww3Mc';
const SHEET_NAME = 'Sheet1';

const fetchStudentData = async () => {
  try {
    const response = await fetch(
      `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:json&sheet=${SHEET_NAME}`
    );
    const text = await response.text();
    const jsonData = JSON.parse(text.substring(47).slice(0, -2));

    return jsonData.table.rows.map(row => ({
      id: row.c[0]?.v?.toString() || '',
      name: row.c[1]?.v || '',
      rollNumber: row.c[2]?.v || '',
      program: row.c[3]?.v || '',
      examCenter: row.c[4]?.v || '',
      location: row.c[5]?.v || '',
      status: row.c[6]?.v || 'Not Marked',
      barcode: row.c[7]?.v?.toString() || ''
    }));
  } catch (error) {
    console.error('Error fetching student data:', error);
    return [];
  }
};

const { width } = Dimensions.get('window');

export default function AttendanceScanner() {
  const [hasPermission, setHasPermission] = useState(null);
  const [scanned, setScanned] = useState(false);
  const [scannerVisible, setScannerVisible] = useState(false);
  const [studentData, setStudentData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);  
  const [todayCount, setTodayCount] = useState(0);
  const [allStudents, setAllStudents] = useState([]);
  const [pieChartRotation] = useState(new Animated.Value(0));
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  const [selectedProgram, setSelectedProgram] = useState('All Programs');
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const [programs, setPrograms] = useState(['All Programs']);
  const [filteredStudents, setFilteredStudents] = useState([]);
  
  useEffect(() => {
    // Apply program filter to students
    if (selectedProgram === 'All Programs') {
      setFilteredStudents(allStudents);
    } else {
      setFilteredStudents(allStudents.filter(student => student.program === selectedProgram));
    }
  }, [selectedProgram, allStudents]);

  // Calculate percentage for pie chart based on filtered students
  const attendancePercentage = filteredStudents.length > 0 
    ? Math.round((todayCount / filteredStudents.length) * 100) 
    : 0;

  const handleLogin = () => {
    setLoginError('');
    setLoginLoading(true);
    
    // Simple login validation - you would replace this with real authentication
    setTimeout(() => {
      if (username === 'admin' && password === 'password') {
        setIsLoggedIn(true);
      } else {
        setLoginError('Invalid username or password');
      }
      setLoginLoading(false);
    }, 1500);
  };

  const LoginScreen = () => {
    const [rememberMe, setRememberMe] = useState(false);
    const usernameInputRef = useRef(null);
    const passwordInputRef = useRef(null);
    const [secureTextEntry, setSecureTextEntry] = useState(true);
    
    return (
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.loginContainer}
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={styles.loginContent}>
            <LinearGradient
              colors={['#2596be', '#1a7ca8', '#156c94']}
              style={styles.loginHeader}>
              <View style={styles.logoContainer}>
                <MaterialCommunityIcons name="barcode-scan" size={60} color="white" />
              </View>
              <Text style={styles.loginTitle}>Attendance Scanner</Text>
              <Text style={styles.loginSubtitle}>Login to continue</Text>
            </LinearGradient>
            
            <View style={styles.loginForm}>
              <View style={styles.inputContainer}>
                <MaterialIcons name="person" size={22} color="#666" style={styles.inputIcon} />
                <TextInput
                  ref={usernameInputRef}
                  style={styles.input}
                  placeholder="Username"
                  value={username}
                  onChangeText={setUsername}
                  autoCapitalize="none"
                  returnKeyType="next"
                  onSubmitEditing={() => passwordInputRef.current.focus()}
                />
              </View>
              
              <View style={styles.inputContainer}>
                <MaterialIcons name="lock" size={22} color="#666" style={styles.inputIcon} />
                <TextInput
                  ref={passwordInputRef}
                  style={styles.input}
                  placeholder="Password"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={secureTextEntry}
                  returnKeyType="done"
                  onSubmitEditing={handleLogin}
                />
                <TouchableOpacity 
                  style={styles.eyeIcon}
                  onPress={() => setSecureTextEntry(!secureTextEntry)}
                >
                  <MaterialIcons 
                    name={secureTextEntry ? "visibility" : "visibility-off"} 
                    size={22} 
                    color="#666" 
                  />
                </TouchableOpacity>
              </View>
              
              {loginError ? (
                <Text style={styles.errorText}>{loginError}</Text>
              ) : null}
              
              <View style={styles.rememberContainer}>
                <TouchableOpacity 
                  style={styles.rememberMeButton}
                  onPress={() => setRememberMe(!rememberMe)}
                >
                  <View style={styles.checkbox}>
                    {rememberMe && <MaterialIcons name="check" size={16} color="#2596be" />}
                  </View>
                  <Text style={styles.rememberText}>Remember me</Text>
                </TouchableOpacity>
                <TouchableOpacity>
                  <Text style={styles.forgotText}>Forgot Password?</Text>
                </TouchableOpacity>
              </View>
              
              <TouchableOpacity
                style={styles.loginButton}
                onPress={handleLogin}
                disabled={loginLoading}
              >
                {loginLoading ? (
                  <ActivityIndicator color="white" size="small" />
                ) : (
                  <Text style={styles.loginButtonText}>Login</Text>
                )}
              </TouchableOpacity>
              
              <View style={styles.footer}>
                <LinearGradient
                  colors={['rgba(37, 150, 190, 0.1)', 'rgba(8, 132, 60, 0.1)']}
                  style={styles.footerGradient}>
                  <Text style={styles.footerText}>
                    Powered by <Text style={styles.footerHighlight}>Shaheen Hirani</Text>
                  </Text>
                </LinearGradient>
              </View>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    );
  };

  const PieChart = () => {
    const radius = 60;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference * (1 - attendancePercentage / 100);

    return (
      <View style={styles.pieChartContainer}>
        <View style={styles.pieChartWrapper}>
          <Svg height="140" width="140" viewBox="0 0 140 140">
            {/* Background circle */}
            <Circle
              cx="70"
              cy="70"
              r={radius}
              stroke="#e0e0e0"
              strokeWidth="15"
              fill="none"
            />
            {/* Progress circle */}
            <Circle
              cx="70"
              cy="70"
              r={radius}
              stroke="#08843c"
              strokeWidth="15"
              fill="none"
              strokeDasharray={`${circumference} ${circumference}`}
              strokeDashoffset={strokeDashoffset}
              transform={`rotate(-90 70 70)`}
              strokeLinecap="round"
            />
          </Svg>
          <View style={styles.pieChartTextContainer}>
            <Text style={styles.pieChartPercentage}>{attendancePercentage}%</Text>
            <Text style={styles.pieChartLabel}>Present</Text>
          </View>
        </View>
        <View style={styles.legendContainer}>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: '#08843c' }]} />
            <Text style={styles.legendText}>Present ({todayCount})</Text>
          </View>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: '#e0e0e0' }]} />
            <Text style={styles.legendText}>
              Absent ({filteredStudents.length - todayCount})
            </Text>
          </View>
        </View>
      </View>
    );
  };

  useEffect(() => {
    const loadStudentData = async () => {
      setLoading(true);
      try {
        const data = await fetchStudentData();
        setAllStudents(data);
        setFilteredStudents(data);
        
        // Get unique programs for dropdown
        const uniquePrograms = [...new Set(data.map(student => student.program))].filter(Boolean);
        setPrograms(['All Programs', ...uniquePrograms]);
        
      } catch (error) {
        console.error('Error loading student data:', error);
      } finally {
        setLoading(false);
      }
    };
    loadStudentData();
  }, []);

  // Updated permission request function
  useEffect(() => {
    const getPermissions = async () => {
      try {
        const { granted } = await BarCodeScanner.getPermissionsAsync();
        if (!granted) {
          const { status } = await BarCodeScanner.requestPermissionsAsync();
          setHasPermission(status === 'granted');
        } else {
          setHasPermission(granted);
        }
      } catch (error) {
        console.error('Permission error:', error);
        alert('Failed to get camera permission. Please enable camera access in your device settings.');
      }
    };
    getPermissions();
  }, []);  const [manualEntryMode, setManualEntryMode] = useState(false);
  const [rollNumberInput, setRollNumberInput] = useState('');
  const [updateSuccessful, setUpdateSuccessful] = useState(false);

  const handleBarCodeScanned = async ({ type, data }) => {
    try {
      setScanned(true);
      setLoading(true);
      
      console.log('Scanned barcode:', data); // Debug log
      
      // Search in the fetched student list
      const student = filteredStudents.find(s => s.barcode === data);
      console.log('Found student:', student); // Debug log
      
      if (student) {
        setStudentData(student);
        setShowSuccess(true);
        // Mark attendance automatically if not already present
        if (student.status !== 'Present') {
          markAttendance(student);
        }
        setTimeout(() => {
          setShowSuccess(false);
          setScannerVisible(false);
        }, 2000);
      } else {
        alert('Student not found. Please ensure the barcode is registered.');
        setScannerVisible(false);
      }
    } catch (error) {
      console.error('Scanning error:', error);
      alert('Error scanning barcode. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const updateGoogleSheet = async (student) => {
    try {
      // This is a simplified version - in production you would use a proper API endpoint
      // Find the row index for the student (rowIndex = studentIndex + 2 to account for header row)
      const studentIndex = allStudents.findIndex(s => s.id === student.id);
      if (studentIndex === -1) return false;
      
      const rowIndex = studentIndex + 2; // +2 because Google Sheets is 1-indexed and has a header
      
      console.log(`Updating student ${student.name} at row ${rowIndex} to Present`);
      
      // In a real implementation, you would make an API call to your backend service
      // that has the necessary permissions to update the Google Sheet
      
      // For now we'll simulate a successful update
      return true;
    } catch (error) {
      console.error('Error updating Google Sheet:', error);
      return false;
    }
  };

  const findStudentByRollNumber = (rollNumber) => {
    return filteredStudents.find(s => 
      s.rollNumber.toLowerCase() === rollNumber.toLowerCase()
    );
  };

  const handleManualEntry = async () => {
    if (!rollNumberInput.trim()) {
      alert('Please enter a roll number');
      return;
    }
    
    setLoading(true);
    
    try {
      const student = findStudentByRollNumber(rollNumberInput);
      
      if (student) {
        setStudentData(student);
        if (student.status !== 'Present') {
          markAttendance(student);
        } else {
          alert(`${student.name} is already marked Present`);
        }
      } else {
        alert('Student not found. Please check the roll number and try again.');
      }
    } catch (error) {
      console.error('Error marking attendance manually:', error);
      alert('Error marking attendance. Please try again.');
    } finally {
      setRollNumberInput('');
      setLoading(false);
    }
  };

  const markAttendance = async (student) => {
    setLoading(true);
    
    try {
      // Update local state
      const updatedStudent = {
        ...student,
        status: 'Present'
      };
      
      // Update Google Sheet
      const sheetUpdated = await updateGoogleSheet(updatedStudent);
      
      if (sheetUpdated) {
        // Update all students array
        const updatedAllStudents = allStudents.map(s => 
          s.id === updatedStudent.id ? updatedStudent : s
        );
        setAllStudents(updatedAllStudents);
        
        // Update filtered students
        const updatedFilteredStudents = filteredStudents.map(s => 
          s.id === updatedStudent.id ? updatedStudent : s
        );
        setFilteredStudents(updatedFilteredStudents);
        
        // Update student data display
        setStudentData(updatedStudent);
        
        // Update today's count
        setTodayCount(prev => prev + 1);
        
        setUpdateSuccessful(true);
        setTimeout(() => setUpdateSuccessful(false), 2000);
      } else {
        // Still update UI but inform user about sync issue
        alert('Attendance marked locally but failed to update Google Sheet. Please try again later.');
        
        // Update local state anyway
        const updatedAllStudents = allStudents.map(s => 
          s.id === student.id ? {...s, status: 'Present'} : s
        );
        setAllStudents(updatedAllStudents);
        setStudentData(prev => ({...prev, status: 'Present'}));
        setTodayCount(prev => prev + 1);
      }
    } catch (error) {
      console.error('Error marking attendance:', error);
      alert('Error marking attendance. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!isLoggedIn) {
    return <LoginScreen />;
  }

  if (hasPermission === null) {
    return <Text>Requesting camera permission...</Text>;
  }
  if (hasPermission === false) {
    return <Text>No access to camera</Text>;
  }

  return (
    <ScrollView style={styles.container}>
      <LinearGradient
        colors={['#2596be', '#1a7ca8', '#156c94']}
        style={styles.headerGradient}>
        <View style={styles.headerContent}>
          <Text style={styles.headerText}>Attendance Scanner</Text>
          <Text style={styles.subHeaderText}>Digital Attendance Management</Text>
          <TouchableOpacity 
            style={styles.logoutButton}
            onPress={() => setIsLoggedIn(false)}
          >
            <MaterialIcons name="logout" size={20} color="white" />
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
      
      <View style={styles.programSelectorContainer}>
        <Text style={styles.programSelectorLabel}>Select Program:</Text>
        <TouchableOpacity 
          style={styles.programSelector}
          onPress={() => setDropdownVisible(!dropdownVisible)}
        >
          <Text style={styles.programSelectorText}>{selectedProgram}</Text>
          <MaterialIcons 
            name={dropdownVisible ? "arrow-drop-up" : "arrow-drop-down"} 
            size={24} 
            color="#2596be" 
          />
        </TouchableOpacity>
        
        {dropdownVisible && (
          <View style={styles.dropdown}>
            {programs.map((program, index) => (
              <TouchableOpacity
                key={index}
                style={[
                  styles.dropdownItem,
                  selectedProgram === program && styles.selectedDropdownItem
                ]}
                onPress={() => {
                  setSelectedProgram(program);
                  setDropdownVisible(false);
                }}
              >
                <Text 
                  style={[
                    styles.dropdownItemText,
                    selectedProgram === program && styles.selectedDropdownItemText
                  ]}
                >
                  {program}
                </Text>
                <Text style={styles.programCount}>
                  {program === 'All Programs' 
                    ? allStudents.length 
                    : allStudents.filter(s => s.program === program).length}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>
      
      <View style={styles.statsContainer}>
        <PieChart />
        <View style={styles.statsTextContainer}>
          <Text style={styles.statTitle}>
            Today's Attendance: {todayCount}
          </Text>
          <Text style={styles.statTitle}>
            Total Students: {filteredStudents.length}
          </Text>
          {selectedProgram !== 'All Programs' && (
            <Text style={styles.statSubtitle}>
              Program: {selectedProgram}
            </Text>
          )}
        </View>
      </View>

      {showSuccess && (
        <View style={styles.successOverlay}>
          <Text style={styles.successText}>Successfully Scanned!</Text>
        </View>
      )}

      <TouchableOpacity
        style={styles.scanButton}
        onPress={() => {
          setScanned(false);
          setScannerVisible(true);
        }}>
        <Text style={styles.scanButtonText}>Scan Barcode</Text>
      </TouchableOpacity>
      
      <Modal visible={scannerVisible} animationType="slide">
        <View style={styles.scannerContainer}>
          <BarCodeScanner
            onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
            barCodeTypes={[
              BarCodeScanner.Constants.BarCodeType.code128,
              BarCodeScanner.Constants.BarCodeType.code39,
              BarCodeScanner.Constants.BarCodeType.ean13,
              BarCodeScanner.Constants.BarCodeType.ean8,
            ]}
            style={StyleSheet.absoluteFillObject}
          />
          <View style={styles.scannerOverlay}>
            <View style={styles.scannerMarker} />
            <Text style={styles.scannerText}>Position barcode within frame</Text>
          </View>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => {
              setScannerVisible(false);
              setScanned(false);
            }}>
            <MaterialIcons name="close" size={24} color="white" />
          </TouchableOpacity>
          {scanned && (
            <TouchableOpacity
              style={styles.rescanButton}
              onPress={() => setScanned(false)}>
              <Text style={styles.rescanButtonText}>Tap to Scan Again</Text>
            </TouchableOpacity>
          )}
        </View>
      </Modal>

      {loading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#2596be" />
          <Text>Processing...</Text>
        </View>
      )}

      {studentData && (
        <View style={styles.resultContainer}>
          <Text style={styles.resultText}>Name: {studentData.name}</Text>
          <Text style={styles.resultText}>Roll No: {studentData.rollNumber}</Text>
          <Text style={styles.resultText}>Program: {studentData.program}</Text>
          <Text style={styles.resultStatusText}>
            Status: <Text style={{color: studentData.status === 'Present' ? '#08843c' : '#666'}}>
              {studentData.status}
            </Text>
          </Text>
          {studentData.status !== 'Present' && (
            <TouchableOpacity style={styles.markButton} onPress={markAttendance}>
              <Text style={styles.markButtonText}>Mark Attendance</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
      
      <View style={styles.footer}>
        <LinearGradient
          colors={['rgba(37, 150, 190, 0.1)', 'rgba(8, 132, 60, 0.1)']}
          style={styles.footerGradient}>
          <Text style={styles.footerText}>
            Powered by <Text style={styles.footerHighlight}>Shaheen Hirani</Text>
          </Text>
        </LinearGradient>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  // Login screen styles
  loginContainer: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loginContent: {
    flex: 1,
  },
  loginHeader: {
    padding: 30,
    paddingTop: 60,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    alignItems: 'center',
  },
  logoContainer: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
  },
  loginTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 5,
  },  loginSubtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
  },
  loginForm: {
    flex: 1,
    padding: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    backgroundColor: 'white',
    borderRadius: 8,
    marginBottom: 15,
    paddingHorizontal: 10,
    height: 50,
  },
  inputIcon: {
    marginRight: 10,
  },
  eyeIcon: {
    position: 'absolute',
    right: 15,
  },
  input: {
    flex: 1,
    height: 50,
    fontSize: 16,
    color: '#333',
  },
  rememberContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 25,
  },
  rememberMeButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkbox: {
    width: 20,
    height: 20,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 4,
    marginRight: 8,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  rememberText: {
    fontSize: 14,
    color: '#666',
  },
  forgotText: {
    fontSize: 14,
    color: '#2596be',
    fontWeight: '500',
  },
  loginButton: {
    backgroundColor: '#2596be',
    height: 50,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
  loginButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  errorText: {
    color: '#d32f2f',
    marginBottom: 15,
    textAlign: 'center',
  },
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  headerGradient: {
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 30,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  headerContent: {
    paddingHorizontal: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  subHeaderText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 5,
  },
  scanButton: {
    backgroundColor: '#2596be',
    margin: 20,
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  scanButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  scannerContainer: {
    flex: 1,
    backgroundColor: 'black',
    position: 'relative',
  },
  scannerOverlay: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scannerMarker: {
    width: 280,
    height: 280,
    borderWidth: 2,
    borderColor: '#2596be',
    backgroundColor: 'transparent',
    borderRadius: 20,
  },
  scannerText: {
    color: 'white',
    marginTop: 20,
    fontSize: 16,
    textAlign: 'center',
    backgroundColor: 'rgba(0,0,0,0.7)',
    padding: 8,
    borderRadius: 8,
  },
  closeButton: {
    position: 'absolute',
    top: 50,
    right: 20,
    backgroundColor: 'rgba(0,0,0,0.6)',
    padding: 10,
    borderRadius: 30,
  },
  rescanButton: {
    position: 'absolute',
    bottom: 50,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  rescanButtonText: {
    color: 'white',
    backgroundColor: '#2596be',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    fontSize: 16,
    fontWeight: 'bold',
  },
  loadingContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.8)',
  },
  resultContainer: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  resultText: {
    fontSize: 16,
    marginBottom: 10,
    color: '#333',
  },
  resultStatusText: {
    fontSize: 16,
    marginBottom: 10,
    fontWeight: 'bold',
    color: '#333',
  },
  markButton: {
    backgroundColor: '#08843c',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  markButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  successOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(8, 132, 60, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  successText: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  statsContainer: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 8,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  statsTextContainer: {
    marginTop: 15,
  },
  statTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  statSubtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  pieChartContainer: {
    alignItems: 'center',
    marginBottom: 15,
  },
  pieChartWrapper: {
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  pieChartTextContainer: {
    position: 'absolute',
    alignItems: 'center',
  },
  pieChartPercentage: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  pieChartLabel: {
    fontSize: 14,
    color: '#666',
  },
  legendContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 10,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  legendDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 6,
  },
  legendText: {
    fontSize: 14,
    color: '#666',
  },
  logoutButton: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 10 : 0,
    right: 20,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
  },
  logoutText: {
    color: 'white',
    marginLeft: 5,
    fontSize: 12,
  },
  programSelectorContainer: {
    margin: 20,
    marginBottom: 0,
  },
  programSelectorLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  programSelector: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  programSelectorText: {
    fontSize: 16,
    color: '#333',
  },
  dropdown: {
    backgroundColor: 'white',
    marginTop: 5,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    maxHeight: 300,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  dropdownItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  selectedDropdownItem: {
    backgroundColor: 'rgba(8,132,60,0.1)',
  },
  dropdownItemText: {
    fontSize: 16,
    color: '#333',
  },
  selectedDropdownItemText: {
    color: '#08843c',
    fontWeight: 'bold',
  },
  programCount: {
    fontSize: 14,
    color: '#666',
    backgroundColor: '#f5f5f5',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
  },
  footer: {
    margin: 20,
    marginTop: 10,
  },
  footerGradient: {
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    color: '#666',
  },  footerHighlight: {
    color: '#2596be',
    fontWeight: 'bold',
  }
});